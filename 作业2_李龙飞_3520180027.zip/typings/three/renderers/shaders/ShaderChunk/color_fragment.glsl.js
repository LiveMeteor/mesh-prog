export default /* glsl */`
#ifdef USE_COLOR

	diffuseColor.rgb *= vColor;

#endif
`;

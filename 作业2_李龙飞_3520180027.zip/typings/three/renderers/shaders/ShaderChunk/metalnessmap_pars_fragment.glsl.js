export default /* glsl */`
#ifdef USE_METALNESSMAP

	uniform sampler2D metalnessMap;

#endif
`;

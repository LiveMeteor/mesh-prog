export default /* glsl */`
vec3 transformed = vec3( position );
`;

namespace fw {
    export interface Point {
        x: number;
        y: number;
    }
}

